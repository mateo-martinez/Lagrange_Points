function porkChopEstimate(r1,r2){

let mu=1

let a=(r1+r2)/2

let transferTime=Math.PI*Math.sqrt(a*a*a/mu)

return transferTime

}

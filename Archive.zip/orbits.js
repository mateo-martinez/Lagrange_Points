function lagrangePoints(m){

return [

{x:1-Math.cbrt(m/3),y:0},
{x:1+Math.cbrt(m/3),y:0},
{x:-1-(5*m/12),y:0},
{x:0.5-m,y:Math.sqrt(3)/2},
{x:0.5-m,y:-Math.sqrt(3)/2}

]

}

let scene=new THREE.Scene()

let camera=new THREE.PerspectiveCamera(
60,
window.innerWidth/window.innerHeight,
0.1,
10000
)

camera.position.z=8

let renderer=new THREE.WebGLRenderer({antialias:true})
renderer.setSize(window.innerWidth,window.innerHeight)

document.body.appendChild(renderer.domElement)

let controls=new THREE.OrbitControls(camera,renderer.domElement)

let probes=[]

initSolarSystem()

function spawnProbe(){

let mesh=new THREE.Mesh(
new THREE.SphereGeometry(.04,12,12),
new THREE.MeshBasicMaterial({color:0x00ffff})
)

mesh.userData={x:1.2,y:0,vx:0,vy:.1}

scene.add(mesh)
probes.push(mesh)

}

function animate(){

requestAnimationFrame(animate)

let dt=.01*document.getElementById("speed").value

updateSolarSystem(dt)

probes.forEach(p=>{

cr3bpStep(p.userData,.0123,dt)

p.position.x=p.userData.x
p.position.y=p.userData.y

})

renderer.render(scene,camera)

}

animate()


let scene=new THREE.Scene()

let camera=new THREE.PerspectiveCamera(
60,
window.innerWidth/window.innerHeight,
0.1,
10000
)

camera.position.z=8

let renderer=new THREE.WebGLRenderer({antialias:true})
renderer.setSize(window.innerWidth,window.innerHeight)

document.body.appendChild(renderer.domElement)

let controls=new THREE.OrbitControls(camera,renderer.domElement)

let probes=[]
let trails=[]

initSolarSystem()

function spawnProbe(){

let mesh=new THREE.Mesh(
new THREE.SphereGeometry(.04,12,12),
new THREE.MeshBasicMaterial({color:0x00ffff})
)

mesh.userData={x:1.2,y:0,vx:0,vy:.1}

scene.add(mesh)
probes.push(mesh)
trails.push([])

}

function spawnHalo(){

let mesh=new THREE.Mesh(
new THREE.SphereGeometry(.04,12,12),
new THREE.MeshBasicMaterial({color:0xff00ff})
)

mesh.userData={x:1.1,y:0,vx:0,vy:.2}

scene.add(mesh)
probes.push(mesh)
trails.push([])

}

function spawnTrojan(){

for(let i=0;i<20;i++){

let mesh=new THREE.Mesh(
new THREE.SphereGeometry(.03,10,10),
new THREE.MeshBasicMaterial({color:0xffff00})
)

mesh.userData={
x:.5+(Math.random()-.5)*.1,
y:.86+(Math.random()-.5)*.1,
vx:0,
vy:0
}

scene.add(mesh)
probes.push(mesh)
trails.push([])

}

}

function clearObjects(){

probes.forEach(p=>scene.remove(p))
probes=[]
trails=[]

}

function drawTrail(points){

if(points.length<2) return

let geometry=new THREE.BufferGeometry().setFromPoints(points)

let material=new THREE.LineDashedMaterial({
color:0x00ffff,
dashSize:.05,
gapSize:.05
})

let line=new THREE.Line(geometry,material)
line.computeLineDistances()

scene.add(line)

}

function animate(){

requestAnimationFrame(animate)

let dt=.01*document.getElementById("speed").value

updateSolarSystem(dt)

probes.forEach((p,i)=>{

cr3bpStep(p.userData,.0123,dt)

p.position.x=p.userData.x
p.position.y=p.userData.y

trails[i].push(new THREE.Vector3(p.position.x,p.position.y,0))

if(trails[i].length>200) trails[i].shift()

drawTrail(trails[i])

})

document.getElementById("count").innerText=probes.length

renderer.render(scene,camera)

}

animate()

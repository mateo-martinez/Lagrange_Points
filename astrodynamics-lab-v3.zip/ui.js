
document.getElementById("spawnProbe").onclick=spawnProbe
document.getElementById("halo").onclick=spawnHalo
document.getElementById("trojan").onclick=spawnTrojan
document.getElementById("clear").onclick=clearObjects

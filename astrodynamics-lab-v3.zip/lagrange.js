
function lagrangePoints(mu){

return [

{x:1-Math.cbrt(mu/3),y:0},
{x:1+Math.cbrt(mu/3),y:0},
{x:-1-(5*mu/12),y:0},
{x:0.5-mu,y:Math.sqrt(3)/2},
{x:0.5-mu,y:-Math.sqrt(3)/2}

]

}

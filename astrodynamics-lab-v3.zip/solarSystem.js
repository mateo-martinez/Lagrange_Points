
const planets=[]

function createPlanet(radius,color,distance,speed){

let mesh=new THREE.Mesh(
new THREE.SphereGeometry(radius,32,32),
new THREE.MeshBasicMaterial({color:color})
)

mesh.userData={
distance:distance,
speed:speed,
angle:Math.random()*Math.PI*2
}

scene.add(mesh)
planets.push(mesh)

}

function initSolarSystem(){

createPlanet(.5,0xffff00,0,0)
createPlanet(.05,0x888888,.8,4.7)
createPlanet(.07,0xffaa00,1,3.5)
createPlanet(.09,0x3fa9ff,1.4,2.9)
createPlanet(.05,0xff5533,1.8,2.4)
createPlanet(.3,0xffcc88,2.5,1.3)
createPlanet(.25,0xffddaa,3.3,1.0)
createPlanet(.15,0x88ccff,4.1,.7)
createPlanet(.15,0x3355ff,4.8,.5)

}

function updateSolarSystem(dt){

planets.forEach(p=>{

p.userData.angle+=dt*p.userData.speed

p.position.x=Math.cos(p.userData.angle)*p.userData.distance
p.position.z=Math.sin(p.userData.angle)*p.userData.distance

})

}


function cr3bpStep(p,m,dt){

let dx1=p.x+m
let dy1=p.y

let dx2=p.x-(1-m)
let dy2=p.y

let r1=Math.sqrt(dx1*dx1+dy1*dy1)
let r2=Math.sqrt(dx2*dx2+dy2*dy2)

let ax=p.x+2*p.vy-(1-m)*dx1/(r1*r1*r1)-m*dx2/(r2*r2*r2)
let ay=p.y-2*p.vx-(1-m)*dy1/(r1*r1*r1)-m*dy2/(r2*r2*r2)

p.vx+=ax*dt
p.vy+=ay*dt

p.x+=p.vx
p.y+=p.vy

return p
}
